// navbar.js

// نظام الترجمة للنافبار
const navbarTranslations = {
    en: {
        women: "Women",
        men: "Men",
        girls: "Girls",
        boys: "Boys",
        babies: "Babies",
        offers: "Offers"
    },
    ar: {
        women: "نسائي",
        men: "رجالي",
        girls: "بنات",
        boys: "أولاد",
        babies: "أطفال",
        offers: "العروض"
    }
};

// دالة لعمل الـ Navbar
function createNavbar(currentLang = "en") {
    const t = navbarTranslations[currentLang];

    return `
    <nav class="navbar">
        <div class="nav-container">

            <!-- Logo -->
            <a href="index.html" class="nav-logo">
                STYLE<span>SHOP</span>
            </a>

            <!-- Desktop Navigation -->
            <div class="nav-menu">
                <a href="women.html" class="nav-link" data-translate="women">${t.women}</a>
                <a href="men.html" class="nav-link" data-translate="men">${t.men}</a>
                <a href="girls.html" class="nav-link" data-translate="girls">${t.girls}</a>
                <a href="boys.html" class="nav-link" data-translate="boys">${t.boys}</a>
                <a href="babies.html" class="nav-link" data-translate="babies">${t.babies}</a>
                <a href="offers.html" class="nav-link" data-translate="offers">${t.offers}</a>
            </div>

            <!-- Right section always visible -->
            <div class="nav-right always-visible">
                <button class="dark-mode-btn" id="darkModeBtn">
                    <i class="fas fa-moon"></i>
                </button>

                <button class="language-btn" id="languageBtn">
                    <span class="lang-text">${currentLang === "en" ? "AR" : "EN"}</span>
                    <i class="fas fa-globe"></i>
                </button>

                <!-- Cart -->
                <a href="cart.html" class="cart-btn" id="cartBtn">
                    <i class="fas fa-shopping-bag"></i>
                    <span class="cart-badge" id="cartBadge">0</span>
                </a>
            </div>

            <!-- Mobile Menu Button -->
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>

        </div>

        <!-- Mobile Menu -->
        <div class="mobile-menu" id="mobileMenu">
            <div class="mobile-links">
                <a href="women.html" class="mobile-link" data-translate="women">${t.women}</a>
                <a href="men.html" class="mobile-link" data-translate="men">${t.men}</a>
                <a href="girls.html" class="mobile-link" data-translate="girls">${t.girls}</a>
                <a href="boys.html" class="mobile-link" data-translate="boys">${t.boys}</a>
                <a href="babies.html" class="mobile-link" data-translate="babies">${t.babies}</a>
                <a href="offers.html" class="mobile-link" data-translate="offers">${t.offers}</a>
            </div>
        </div>
    </nav>
    `;
}

// دالة تحديث النافبار عند تغيير اللغة
function updateNavbarLanguage(lang) {
    const navbarContainer = document.getElementById("navbar-container");
    if (navbarContainer) {
        navbarContainer.innerHTML = createNavbar(lang);
        attachNavbarEvents();
    }
}

// دالة ربط الأحداث في النافبار
function attachNavbarEvents() {
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    // Mobile Menu Toggle
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener("click", () => {
            mobileMenu.classList.toggle("open");

            const isOpen = mobileMenu.classList.contains("open");

            mobileMenuBtn.innerHTML = isOpen
                ? '<i class="fas fa-times"></i>'
                : '<i class="fas fa-bars"></i>';
        });
    }

    // Toggle Language
    const languageBtn = document.getElementById("languageBtn");
    if (languageBtn) {
        languageBtn.addEventListener("click", () => {
            const event = new CustomEvent("languageToggle");
            document.dispatchEvent(event);
        });
    }

    // Toggle Dark Mode
    const darkModeBtn = document.getElementById("darkModeBtn");
    if (darkModeBtn) {
        darkModeBtn.addEventListener("click", () => {
            const event = new CustomEvent("darkModeToggle");
            document.dispatchEvent(event);
        });
    }
}

// تحميل النافبار عند فتح الصفحة
function loadNavbar() {
    const navbarContainer = document.getElementById("navbar-container");
    if (navbarContainer) {
        const savedLang = localStorage.getItem("preferredLanguage") || "en";
        navbarContainer.innerHTML = createNavbar(savedLang);
        attachNavbarEvents();
    }
}

document.addEventListener("DOMContentLoaded", loadNavbar);
